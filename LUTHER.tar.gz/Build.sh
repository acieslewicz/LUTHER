#
# Simply set execute mode on LUTHER
#
chmod +x LUTHER
